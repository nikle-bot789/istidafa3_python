import subprocess
import sys

# دالة لتثبيت المكتبات إذا لم تكن مثبتة
def install_packages():
    packages = ["pyTelegramBotAPI", "googlesearch-python"]
    for package in packages:
        try:
            __import__(package)  # محاولة استيراد المكتبة
        except ImportError:
            print(f"⚙️ تثبيت المكتبة {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# تثبيت المكتبات
install_packages()

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from googlesearch import search

# توكن البوت الذي حصلت عليه من BotFather
TOKEN = '7843510678:AAH6FGvqWl87ZNlmS7GriHOgkyLIT51Ucxs'

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text('مرحبا! اكتب لي ما تريد البحث عنه.')

async def search_google(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.message.text
    results = search(query, num_results=10)  # عدد النتائج التي تريدها

    response = "نتائج البحث:\n"
    for result in results:
        response += f"{result}\n"

    await update.message.reply_text(response)

def main() -> None:
    application = ApplicationBuilder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, search_google))

    application.run_polling()

if __name__ == '__main__':
    main()