import subprocess
import sys

# دالة لتثبيت المكتبات إذا لم تكن مثبتة
def install_packages():
    packages = ["pyTelegramBotAPI", "aiohttp", "deep-translator"]
    for package in packages:
        try:
            __import__(package)  # محاولة استيراد المكتبة
        except ImportError:
            print(f"⚙️ تثبيت المكتبة {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# تثبيت المكتبات
install_packages()

# بعد التثبيت نقوم باستيراد المكتبات
import telebot
import aiohttp
import asyncio
import webbrowser
import os
from deep_translator import GoogleTranslator

# التوكن الخاص بالبوت
token = "7747612730:AAGYLOVFz02DyA-6LGGaH9RXl3HmxmyISHE"
bot = telebot.TeleBot(token)

# زر "Start"
@bot.message_handler(commands=['start'])
def send_welcome(message):
    # رسالة ترحيب بعد تعديلها
    bot.send_message(
        message.chat.id, 
        "*💬 مرحباً بك في بوت التحويل إلى صور! 🎨*\n\n" 
        "*أرسل لي النص بأي لغة وسأقوم بتحويله إلى صورة!*\n\n"
        "*تم تطوير البوت بواسطة [@Cornerdzz]*", 
        parse_mode='Markdown'  # استخدام Markdown لتنسيق النصوص
    )

# دالة لإرسال طلب للحصول على رابط الصورة
async def get_image_url(session, text):
    headers = {
        'Host': 'api.getimg.ai',
        'Accept': 'application/json',
        'Authorization': 'Bearer key-3XbWkFO34FVCQUnJQ6A3qr702Eu7DDR1dqoJOyhMHqhruEhs22KUzR7w631ZFiA5OFZIba7i44qDQEMpKxzegOUm83vCfILb',
        'Content-Type': 'application/json',
        'User-Agent': 'okhttp/4.12.0',
        'Connection': 'keep-alive',
    }
    data = {
        'height': 1024,
        'model': 'realvis-xl-v4',
        'negative_prompt': 'nude, naked, porn, sexual, explicit, adult, sex, xxx, erotic, blowjob, masturbation, intercourse, hentai, vulgar, profane, obscene, dirty, slut, whore, rape, fetish, gangbang, threesome, stripper, escort',
        'prompt': text,
        'response_format': 'url',
        'seed': 0,
        'steps': 30,
        'width': 1024,
    }
    async with session.post('https://api.getimg.ai/v1/stable-diffusion-xl/text-to-image', headers=headers, json=data) as response:
        return await response.json()

# دالة لإحضار صور متعددة
async def fetch_multiple_images(session, text):
    tasks = [get_image_url(session, text) for _ in range(5)]
    results = await asyncio.gather(*tasks)
    for result in results:
        if 'url' in result and result['url']:
            return result['url']
    return None

# دالة لإرسال الصورة إذا تم تحويل النص بنجاح
async def send_first_successful_request(message):
    user_input = message.text
    
    # ترجمة النص إلى الإنجليزية باستخدام deep_translator
    translated_text = GoogleTranslator(source='auto', target='en').translate(user_input)

    async with aiohttp.ClientSession() as session:
        image_url = await fetch_multiple_images(session, translated_text)
    
    if image_url:
        # إرسال الصورة مع رابط حساب المطور في خانة النص
        bot.send_photo(
            message.chat.id, 
            image_url, 
            caption="*تم عبر [@Cornerdzz]*", 
            parse_mode='Markdown'  # استخدام Markdown لعرض الرابط بشكل صحيح
        )
    else:
        bot.reply_to(message, "لا يوجد رابط في النص. حاول إرسال نص آخر.")

# التعامل مع الرسائل
@bot.message_handler(func=lambda message: True)
def handle_message(message):
    # تشغيل الدالة غير المتزامنة باستخدام asyncio
    asyncio.run(send_first_successful_request(message))

# تشغيل البوت بشكل مستمر
while True:
    try:
        print("🚀 يتم تشغيل البوت...")
        bot.polling(non_stop=True)  # تشغيل البوت بدون توقف
    except Exception as e:
        print(f"⚠️ حدث خطأ: {e}. إعادة تشغيل البوت بعد 5 ثوانٍ.")