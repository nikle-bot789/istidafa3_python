import requests
import telebot
from bs4 import BeautifulSoup


token = '7781874465:AAHw6d25CkHne5Bq_xH8uwsVJ8qO2VSn4WM'


bot = telebot.TeleBot(token)

def get_image_urls(search_query):
    response = requests.get(f'https://www.brandcrowd.com/maker/logos/page1?Text={search_query}&SearchText=&WasModalContinueClicked=true')

    soup = BeautifulSoup(response.text, 'html.parser')
    image_urls = []
    for img_tag in soup.find_all('img'):
        img_url = img_tag.get('src')
        if img_url and img_url.startswith('http'):
            image_urls.append(img_url)
    
    return image_urls

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "أهلاً! من فضلك، أرسل الاسم لعمل لوجو")

@bot.message_handler(func=lambda message: True)
def send_images(message):
    search_query = message.text
    bot.reply_to(message, f"جاري العمل لوجو  لـ '{search_query}'...")

    image_urls = get_image_urls(search_query)
    
    if image_urls:
        for img_url in image_urls[:10]:
            bot.send_photo(message.chat.id, img_url)
    else:
        bot.reply_to(message, "لم يتم العثور على صور.")

bot.polling()