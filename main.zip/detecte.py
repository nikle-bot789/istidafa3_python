import subprocess
import sys
import psutil
import ast
import time

# Fonction pour obtenir les bibliothèques importées d'un script donné
def get_required_libraries(script_content):
    tree = ast.parse(script_content)
    libraries = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                libraries.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            libraries.add(node.module)
    return list(libraries)

# Fonction pour installer les bibliothèques si elles ne sont pas déjà installées
def install_packages(libraries):
    for package in libraries:
        try:
            __import__(package)
        except ImportError:
            print(f"⚙️ Installation de la bibliothèque {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Fonction pour surveiller les nouveaux scripts Python en cours d'exécution
def monitor_python_scripts():
    print("Surveillance des scripts Python en cours...")
    
    # Liste des processus en cours (psutil)
    while True:
        for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
            try:
                if proc.info['name'] == 'python' and len(proc.info['cmdline']) > 1:
                    script_path = proc.info['cmdline'][1]  # Le script Python exécuté
                    if script_path.endswith('.py'):
                        # Lire le script Python pour détecter les bibliothèques
                        with open(script_path, 'r') as script_file:
                            script_content = script_file.read()
                            libraries = get_required_libraries(script_content)
                            install_packages(libraries)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
        time.sleep(5)  # Attendre 5 secondes avant de vérifier à nouveau

# Lancer la surveillance
monitor_python_scripts()
