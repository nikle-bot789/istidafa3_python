try:
	
	import telebot
	import os
	import zipfile
	from PIL import Image
	from io import BytesIO
except:
	import os
	#os.system('pip intall zipfile')
	os.system('pip intall PyTelegramBotAPI')
	
Token = ('7781874465:AAHw6d25CkHne5Bq_xH8uwsVJ8qO2VSn4WM')
bot = telebot.TeleBot(Token)
F = 'imgs'
if not os.path.exists(F):
    os.makedirs(F)
imgs = []

@bot.message_handler(commands=['start'])
def send_welcome(message):
	bot.send_message(message.chat.id,'اهلا بك عزيزي في بوت ضغط الصور لملف zip')
@bot.message_handler(content_types=['photo'])
def hp(m):
    fi = bot.get_file(m.photo[-1].file_id)
    df = bot.download_file(fi.file_path)

    img = Image.open(BytesIO(df))
    ip = os.path.join(F, f"{m.photo[-1].file_id}.jpg")
    img.save(ip)
    imgs.append(ip)

    bot.reply_to(m, f"تم استلام {len(imgs)} صورة!")

def cz(o, imgs):
    with zipfile.ZipFile(o, 'w', zipfile.ZIP_DEFLATED) as zf:
        for i in imgs:
            zf.write(i, os.path.basename(i))

@bot.message_handler(func=lambda m: m.text and m.text.lower() == "ضغط")
def ci(m):
    if len(imgs) == 0:
        bot.reply_to(m, "لم يتم استلام أي صور!")
        return

    zf = "imgs.zip"
    cz(zf, imgs)

    with open(zf, 'rb') as f:
        bot.send_document(m.chat.id, f)

    for i in imgs:
        os.remove(i)
    imgs.clear()
    os.remove(zf)
    bot.reply_to(m, "تم ضغط الصور وإرسال الملف!")
print('تم تشغيل البوت')
bot.polling()