import telebot
from yt_dlp import YoutubeDL
from youtubesearchpython import VideosSearch

# Remplacez par votre token de bot Telegram
BOT_TOKEN = "7848279718:AAEXJ-ka1lutR4pQS5N8PRN5umcb6EdJCvA"
bot = telebot.TeleBot(BOT_TOKEN)

# Dictionnaire pour stocker les choix des utilisateurs
user_choices = {}

@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(
        message,
        "Bienvenue ! Tapez le nom d'une chanson pour commencer. 🎵"
    )

@bot.message_handler(func=lambda message: True)
def search_song(message):
    user_id = message.chat.id
    song_name = message.text
    bot.send_message(user_id, "Recherche en cours... 🔍")
    
    # Recherche de chansons sur YouTube
    videos_search = VideosSearch(song_name, limit=5)
    results = videos_search.result().get("result", [])
    
    if not results:
        bot.send_message(user_id, "Aucune chanson trouvée. Essayez un autre nom.")
        return
    
    # Générer une liste de chansons
    choices = []
    for i, video in enumerate(results):
        title = video['title']
        duration = video['duration']
        choices.append(f"{i+1}. {title} ({duration})")
    
    user_choices[user_id] = results  # Sauvegarder les résultats pour l'utilisateur
    bot.send_message(user_id, "\n".join(choices) + "\n\nTapez le numéro pour télécharger la chanson.")

@bot.message_handler(func=lambda message: message.text.isdigit())
def download_song(message):
    user_id = message.chat.id
    choice = int(message.text) - 1  # Convertir en index
    
    if user_id not in user_choices or choice < 0 or choice >= len(user_choices[user_id]):
        bot.send_message(user_id, "Choix invalide. Veuillez réessayer.")
        return
    
    # Obtenir la vidéo sélectionnée
    video = user_choices[user_id][choice]
    video_url = video['link']
    video_title = video['title']
    
    bot.send_message(user_id, f"Téléchargement de '{video_title}' en cours... 📥")
    
    # Télécharger la chanson
    try:
        ydl_opts = {
            'format': 'bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
            'outtmpl': f'{video_title}.mp3',
        }
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([video_url])
        
        # Envoyer le fichier à l'utilisateur
        with open(f"{video_title}.mp3", "rb") as audio_file:
            bot.send_audio(user_id, audio_file)
    except Exception as e:
        bot.send_message(user_id, f"Erreur lors du téléchargement : {e}")
    finally:
        # Nettoyer la mémoire
        user_choices.pop(user_id, None)

# Lancer le bot
bot.polling()