from datetime import datetime
from telegram import Bot, Update
from telegram.ext import Application, CommandHandler, CallbackContext
import asyncio

# إعداد التوكن الخاص بالبوت
TOKEN = '7837175634:AAEv0kruGSHwOEoU-Og07kmsZFoq5z_jAoU'

# دالة لإرسال الوقت والتاريخ الحالي
async def send_time(update: Update, context: CallbackContext):
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # إرسال الوقت والتاريخ إلى معرف الدردشة للمستخدم
    await update.message.reply_text(f"الوقت والتاريخ الحالي: {current_time}")

async def start(update: Update, context: CallbackContext):
    await update.message.reply_text("مرحبًا! سأرسل لك الوقت والتاريخ بشكل دوري.")
    # إرسال الوقت والتاريخ بشكل دوري كل 5 ثوانٍ
    while True:
        await send_time(update, context)
        await asyncio.sleep(5)

def main():
    application = Application.builder().token(TOKEN).build()

    # إضافة handler للاستجابة للأمر /start
    application.add_handler(CommandHandler("start", start))

    # بدء البوت
    application.run_polling()

if __name__ == '__main__':
    main()
