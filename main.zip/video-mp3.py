import os
import sys
import subprocess

# ✅ Vérifier et installer automatiquement les bibliothèques nécessaires
def install_libraries():
    required_libs = ["ffmpeg-python", "python-telegram-bot"]
    
    for lib in required_libs:
        try:
            __import__(lib.replace("-", "_"))  # Convertir nom du package pour import
        except ImportError:
            print(f"📦 Installation de {lib} en cours...")
            subprocess.run([sys.executable, "-m", "pip", "install", "--no-cache-dir", "--force-reinstall", lib], check=True)

# 🔧 Installation automatique avant importation
install_libraries()

# 📌 Importation après installation
import ffmpeg
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext

# 🔑 Ton Token Telegram (remplace par le tien)
TELEGRAM_TOKEN = "7848279718:AAEXJ-ka1lutR4pQS5N8PRN5umcb6EdJCvA"

# 🎬 Fonction de démarrage
async def start(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text("🎵 Bienvenue ! Envoyez-moi une vidéo et je la convertirai en MP3.")

# 🎥 Fonction pour gérer les vidéos
async def handle_video(update: Update, context: CallbackContext) -> None:
    video_file = update.message.video or update.message.document
    if not video_file:
        await update.message.reply_text("❌ Veuillez envoyer un fichier vidéo valide.")
        return

    # 📥 Téléchargement de la vidéo
    file = await video_file.get_file()
    video_path = f"{video_file.file_id}.mp4"
    await file.download_to_drive(video_path)

    await update.message.reply_text("⏳ Vidéo reçue. Conversion en cours...")

    # 🎼 Conversion MP4 → MP3 avec ffmpeg
    mp3_path = video_path.replace(".mp4", ".mp3")
    try:
        ffmpeg.input(video_path).output(mp3_path, format='mp3', audio_bitrate='192k').run(overwrite_output=True)

        # 📤 Envoi du fichier MP3
        with open(mp3_path, "rb") as audio:
            await update.message.reply_audio(audio)
        await update.message.reply_text("✅ Conversion terminée. Voici votre fichier MP3.")
    except Exception as e:
        await update.message.reply_text(f"⚠️ Erreur lors de la conversion : {e}")
    finally:
        # 🗑️ Nettoyage des fichiers temporaires
        if os.path.exists(video_path):
            os.remove(video_path)
        if os.path.exists(mp3_path):
            os.remove(mp3_path)

# 🏁 Fonction principale
def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    # 📌 Ajout des commandes et gestion des vidéos
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.VIDEO | filters.Document.ALL, handle_video))

    print("🚀 Le bot est en cours d'exécution...")
    app.run_polling()

# ▶️ Lancer le bot
if __name__ == "__main__":
    main()
