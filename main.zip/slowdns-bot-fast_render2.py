import logging
import time
import subprocess
import sys
import telebot
from telebot import types
import dns.resolver
from concurrent.futures import ThreadPoolExecutor

# 🔹 تثبيت المكتبات المفقودة تلقائيًا
def install_packages():
    try:
        import dns
        import telebot
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "dnspython", "pyTelegramBotAPI"])
        import dns  # تأكيد الاستيراد بعد التثبيت
        import telebot

install_packages()

# 🔹 إعدادات البوت
TOKEN = "7756358682:AAFu0f5BAVkl2Sg8Ngmw-2ta5tCyO-LOSJA"  # ضع هنا التوكن الخاص بك
bot = telebot.TeleBot(TOKEN)

# 🔹 قائمة المستخدمين المسموح لهم
ALLOWED_USERS = {1726923679, 1772564386, 7255189049}  # استبدل هذه القيم بمعرفات المستخدمين المسموح لهم

# 🔹 تهيئة نظام التسجيل لتسجيل الأخطاء
logging.basicConfig(level=logging.INFO)

# 🔹 اسم ملف التقرير النهائي
REPORT_FILE = "slowdns_report.txt"

# 🔹 النطاق المستخدم لاختبار دعم SlowDNS
TEST_DOMAIN = "google.com"

# 🔹 تحسين سرعة الفحص باستخدام `ThreadPoolExecutor`
def check_slowdns_support(dns_server):
    try:
        resolver = dns.resolver.Resolver(configure=False)
        resolver.nameservers = [dns_server]
        resolver.lifetime = 2  # تقليل المهلة لسرعة الكشف
        start_time = time.time()
        response = resolver.resolve(TEST_DOMAIN, "A", lifetime=2)
        end_time = time.time()

        if response.rrset:
            return f"✅ {dns_server} يدعم SlowDNS - ⏳ {round(end_time - start_time, 2)} ثانية"
        else:
            return f"❌ {dns_server} لا يدعم SlowDNS"
    except dns.resolver.NoAnswer:
        return f"⚠️ {dns_server} لم يرد على الاستعلام"
    except dns.resolver.NXDOMAIN:
        return f"❌ {dns_server} النطاق غير موجود"
    except dns.resolver.Timeout:
        return f"⏳ {dns_server} انتهت المهلة عند الاتصال"
    except Exception as e:
        return f"❌ {dns_server} خطأ: {str(e)}"

# 🔹 التحقق مما إذا كان المستخدم مسموحًا له
def is_allowed(user_id):
    return user_id in ALLOWED_USERS

# 🔹 عند الضغط على /start
@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_id = message.from_user.id

    if not is_allowed(user_id):
        bot.reply_to(message, "🚫 عذرًا، ليس لديك إذن لاستخدام هذا البوت.")
        return

    # إعداد الأزرار
    markup = types.InlineKeyboardMarkup()
    button1 = types.InlineKeyboardButton("فحص DNS واحد", callback_data="check_one_dns")
    button2 = types.InlineKeyboardButton("إرسال ملف لفحص DNS", callback_data="send_file")
    markup.add(button1, button2)

    bot.reply_to(message, "📜 اختر أحد الخيارات:", reply_markup=markup)

# 🔹 عند الضغط على زر فحص DNS واحد
@bot.callback_query_handler(func=lambda call: call.data == "check_one_dns")
def check_single_dns(call):
    bot.send_message(call.message.chat.id, "🔄 أدخل عنوان DNS لفحصه (مثال: 8.8.8.8)")

    @bot.message_handler(func=lambda message: True)
    def handle_dns_input(message):
        dns_server = message.text.strip()
        result = check_slowdns_support(dns_server)
        bot.reply_to(message, result)

# 🔹 عند استلام ملف `.txt`
@bot.callback_query_handler(func=lambda call: call.data == "send_file")
def send_file_request(call):
    bot.send_message(call.message.chat.id, "📥 أرسل ملف `.txt` يحتوي على قائمة عناوين DNS لفحص دعم SlowDNS.")

# 🔹 عند استلام ملف `.txt`
@bot.message_handler(content_types=['document'])
def handle_document(message):
    user_id = message.from_user.id

    if not is_allowed(user_id):
        bot.reply_to(message, "🚫 عذرًا، ليس لديك إذن لاستخدام هذا البوت.")
        return

    file_id = message.document.file_id
    file_info = bot.get_file(file_id)
    downloaded_file = bot.download_file(file_info.file_path)

    # 🔹 حفظ الملف مؤقتًا
    file_path = "dns_list.txt"
    with open(file_path, "wb") as file:
        file.write(downloaded_file)

    bot.reply_to(message, "🔄 جارٍ الفحص بسرعة فائقة، يرجى الانتظار...")

    # 🔹 قراءة عناوين DNS من الملف
    with open(file_path, "r") as file:
        dns_servers = [line.strip() for line in file.readlines() if line.strip()]

    if not dns_servers:
        bot.reply_to(message, "⚠️ الملف فارغ أو لا يحتوي على عناوين DNS صالحة.")
        return

    # 🔹 بدء الفحص باستخدام `ThreadPoolExecutor`
    start_time = time.time()
    results = []

    with ThreadPoolExecutor(max_workers=10) as executor:  # تشغيل 10 عمليات فحص بالتوازي
        results = list(executor.map(check_slowdns_support, dns_servers))

    end_time = time.time()
    total_time = round(end_time - start_time, 2)

    # 🔹 كتابة التقرير إلى ملف
    with open(REPORT_FILE, "w") as report:
        report.write("🔍 **تقرير فحص دعم SlowDNS** 🔍\n\n")
        for result in results:
            report.write(result + "\n")
        report.write(f"\n⏳ **الوقت المستغرق:** {total_time} ثانية\n")

    # 🔹 إرسال التقرير إلى المستخدم
    with open(REPORT_FILE, "rb") as report:
        bot.send_document(message.chat.id, report, caption=f"📄 تم الفحص في {total_time} ثانية!")

# 🔹 تشغيل البوت
bot.infinity_polling()