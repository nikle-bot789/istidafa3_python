from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext
import ipaddress
import os
import asyncio

TOKEN = "7364334735:AAHp3zx6fZCrTP18jQxicwoPf6ltPdwxpfU"  # ضع التوكن الخاص بك هنا

# قاموس لتخزين بيانات المستخدم مؤقتًا
user_data = {}

async def start(update: Update, context: CallbackContext) -> None:
    """يبدأ المحادثة ويطلب من المستخدم إدخال IP البداية."""
    chat_id = update.message.chat_id
    user_data[chat_id] = {"state": "waiting_start_ip"}  # تحديد الحالة
    await update.message.reply_text("🔹 *مرحبًا!* أرسل لي IP البداية.")  

async def receive_ip(update: Update, context: CallbackContext) -> None:
    """يستقبل IP البداية ثم يطلب IP النهاية، بعدها ينشئ القائمة ويرسل الملف."""
    chat_id = update.message.chat_id
    text = update.message.text.strip()

    # التأكد أن الإدخال عبارة عن IP صالح
    try:
        ipaddress.IPv4Address(text)
    except ipaddress.AddressValueError:
        await update.message.reply_text("⚠️ *خطأ:* الرجاء إدخال IP صحيح.")
        return

    if chat_id not in user_data:
        await update.message.reply_text("❌ *خطأ:* يرجى إرسال /start أولاً.")
        return

    state = user_data[chat_id].get("state")

    if state == "waiting_start_ip":
        user_data[chat_id]["start_ip"] = text
        user_data[chat_id]["state"] = "waiting_end_ip"
        await update.message.reply_text("✅ *تم استلام IP البداية.*\n🔹 الآن أرسل لي IP النهاية.")

    elif state == "waiting_end_ip":
        start_ip = user_data[chat_id]["start_ip"]
        end_ip = text

        # تحويل العناوين إلى كائنات IP
        start_ip_obj = ipaddress.IPv4Address(start_ip)
        end_ip_obj = ipaddress.IPv4Address(end_ip)

        if start_ip_obj > end_ip_obj:
            await update.message.reply_text("⚠️ *خطأ:* يجب أن يكون IP النهاية أكبر من أو يساوي IP البداية.")
            return

        # توليد قائمة IPs
        ip_list = [str(ipaddress.IPv4Address(ip)) for ip in range(int(start_ip_obj), int(end_ip_obj) + 1)]

        # حفظ القائمة في ملف
        file_path = f"ips_{chat_id}.txt"
        with open(file_path, "w") as file:
            file.write("\n".join(ip_list))

        # إرسال الملف إلى المستخدم
        await update.message.reply_document(document=open(file_path, "rb"), filename="ip_list.txt")

        # حذف الملف بعد الإرسال
        os.remove(file_path)

        # إعادة تعيين حالة المستخدم
        user_data.pop(chat_id, None)

def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, receive_ip))

    app.run_polling()

if __name__ == '__main__':
    main()