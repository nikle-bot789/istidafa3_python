import subprocess
import sys
import re

# دالة لتثبيت المكتبات إذا لم تكن مثبتة
def install_packages():
    packages = ["pyTelegramBotAPI", "googlesearch-python"]
    for package in packages:
        try:
            __import__(package)  # محاولة استيراد المكتبة
        except ImportError:
            print(f"⚙️ تثبيت المكتبة {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# تثبيت المكتبات
install_packages()

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from googlesearch import search

# توكن البوت الذي حصلت عليه من BotFather
TOKEN = '7843510678:AAH6FGvqWl87ZNlmS7GriHOgkyLIT51Ucxs'

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text('مرحبا! اكتب لي ما تريد البحث عنه.')

async def search_google(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.message.text
    results = list(search(query, num_results=10))  # جلب أكبر عدد ممكن من النتائج (يمكنك تعديل الرقم حسب الحاجة)

    response = "نتائج البحث:\n"
    normal_results = []
    image_links = []
    video_links = []

    for result in results:
        # تصنيف النتائج
        if re.search(r'.(jpg|jpeg|png|gif)$', result):
            image_links.append(result)
        elif 'youtube.com/watch' in result or 'youtu.be/' in result:
            video_links.append(result)
        else:
            normal_results.append(result)

    # إضافة النتائج إلى الرسالة
    if normal_results:
        response += "\nنتائج البحث العادية:\n" + "\n".join(normal_results) + "\n"  # عرض جميع النتائج العادية
    
    if image_links:
        response += "\nروابط الصور:\n" + "\n".join(image_links) + "\n"  # عرض جميع روابط الصور
    
    if video_links:
        response += "\nروابط الفيديوهات:\n" + "\n".join(video_links) + "\n"  # عرض جميع روابط الفيديوهات

    await update.message.reply_text(response)

def main() -> None:
    application = ApplicationBuilder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, search_google))

    application.run_polling()

if __name__ == '__main__':
    main()