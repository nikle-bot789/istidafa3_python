
import subprocess
import sys

# دالة لتثبيت المكتبات إذا لم تكن مثبتة
def install_packages():
    packages = ["pyTelegramBotAPI", "aiohttp", "requests","colorama"]
    for package in packages:
        try:
            __import__(package)  # محاولة استيراد المكتبة
        except ImportError:
            print(f"⚙️ تثبيت المكتبة {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# تثبيت المكتبات
install_packages()
import ssl
import socket
import requests
from colorama import Fore, Style, init

# تهيئة colorama لتنسيق الألوان في المخرجات
init(autoreset=True)

# قائمة الهوستات المطلوبة
hosts = [
    "www.ooredoo.dz", "guest.ooredoo.dz", "feedback.ooredoo.dz", "testapi.ooredoo.dz",
    "dsp.ooredoo.dz", "payement.ooredoo.dz", "arpce.ooredoo.dz", "go.ooredoo.dz",
    "ipmonitor.ooredoo.dz", "testvpn.ooredoo.dz", "enrollment.ooredoo.dz", "osd.ooredoo.dz",
    "yooz.ooredoo.dz", "covid19.ooredoo.dz", "apitest.ooredoo.dz", "AutoDiscover.consultant.ooredoo.dz",
    "ibiza-preprod.ooredoo.dz", "ibiza-test.ooredoo.dz", "staging.my.ooredoo.dz", "ospare.ooredoo.dz",
    "speedtest-or.ooredoo.dz", "speedtest-cst.ooredoo.dz", "digit.ooredoo.dz", "staging.ooredoo.dz",
    "ooredoo.dz", "hashta.ooredoo.dz", "dima.ooredoo.dz", "testchoof.ooredoo.dz",
    "yoozra.ooredoo.dz", "ideabox.ooredoo.dz", "secure.ooredoo.dz", "4g.ooredoo.dz",
    "haya.ooredoo.dz", "accesec.ooredoo.dz", "ibiza-admin.ooredoo.dz", "ibiza.ooredoo.dz",
    "speedtest.ooredoo.dz", "dms.ooredoo.dz", "desk.ooredoo.dz", "collab-edge.ooredoo.dz",
    "omobility.ooredoo.dz", "sip.ooredoo.dz", "webconf.ooredoo.dz", "lync.ooredoo.dz",
    "dialin.ooredoo.dz", "lyncdiscover.ooredoo.dz", "access.ooredoo.dz", "meet.ooredoo.dz",
    "events.ooredoo.dz", "AutoDiscover.ooredoo.dz", "webmailof.ooredoo.dz", "omeeting.ooredoo.dz",
    "ooredoobi.ooredoo.dz", "dms1.ooredoo.dz", "dmsoa.ooredoo.dz", "oprema.ooredoo.dz",
    "opm.ooredoo.dz", "mailarchive.ooredoo.dz", "my.ooredoo.dz", "apps.ooredoo.dz",
    "mms.ooredoo.dz", "eso.ooredoo.dz", "appstorm.ooredoo.dz", "analytics01.ooredoo.dz"
]

def get_tls_info(target):
    """ استخراج معلومات TLS من النطاق أو الـ IP """
    context = ssl.create_default_context()
    is_ip = target.replace(".", "").isdigit()

    if is_ip:
        context.check_hostname = False

    try:
        with socket.create_connection((target, 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=None if is_ip else target) as ssock:
                cert = ssock.getpeercert()
                cipher = ssock.cipher()
                protocol = ssock.version()

                peer_cn = "غير معروف"
                if cert:
                    for field in cert.get("subject", []):
                        if field[0][0] == "commonName":
                            peer_cn = field[0][1]
                            break

                return {
                    "CipherSuite": cipher[0] if cipher else "غير معروف",
                    "Protocol": protocol if protocol else "غير معروف",
                    "Peer CN": peer_cn
                }
    except Exception as e:
        return {"Error": str(e)}

def get_http_headers(url):
    """ جلب الهيدر من الموقع أو IP """
    try:
        response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=5)
        headers = response.headers
        headers["HTTP_Status"] = f"HTTP/{response.raw.version} {response.status_code} {response.reason}"
        return headers
    except requests.exceptions.RequestException as e:
        return {"Error": str(e)}

def scan_target(target):
    """ فحص الهوست أو الـ IP وإظهار النتائج بالألوان المناسبة """
    print(f"\n{Fore.YELLOW}{'='*60}")
    print(f"{Fore.YELLOW} 🔍 فحص الهوست: {target}")
    print(f"{Fore.YELLOW}{'='*60}{Style.RESET_ALL}")

    # استخراج معلومات TLS
    tls_info = get_tls_info(target)
    success = True  # متغير لتحديد نجاح الفحص أو فشله

    for key, value in tls_info.items():
        if "Error" in key:
            color = Fore.RED
            success = False
        else:
            color = Fore.GREEN
        print(f"{color}{key}: {value}")

    print(f"{Fore.YELLOW}{'-' * 50}{Style.RESET_ALL}")

    # استخراج الهيدر HTTP
    url = f"https://{target}"
    headers = get_http_headers(url)

    for key, value in headers.items():
        if "Error" in key:
            color = Fore.RED
            success = False
        else:
            color = Fore.GREEN
        print(f"{color}{key}: {value}")

    # تغيير لون النتيجة النهائية بناءً على نجاح أو فشل الفحص
    final_color = Fore.GREEN if success else Fore.RED
    print(f"{final_color}{'='*60}{Style.RESET_ALL}")

# تشغيل الفحص لجميع الهوستات
for host in hosts:
    scan_target(host)