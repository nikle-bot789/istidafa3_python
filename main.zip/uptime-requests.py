import requests
import time

url = "https://mailk-clone.onrender.com"

try:
    while True:
        response = requests.get(url)

        print("Statut de la requête HTTP:", response.status_code)  # Affiche le statut de la requête

        if response.status_code == 200:
            print("Requête envoyée avec succès!")
            print("Contenu de la réponse :")
            print(response.text)
        else:
            print("La requête a échoué.")

        # Détails de la réponse
        print("Détails de la réponse:")
        for key, value in response.headers.items():
            print(f"{key}: {value}")

        # Pause d'une seconde
        time.sleep(1)

except requests.exceptions.RequestException as e:
    print("Erreur de requête:", e)