import os
import time
import threading
import sys
import marshal
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import UserAlreadyParticipant, InviteHashExpired

# ✅ إعدادات API
api_id = 27860269
api_hash = "76df60f2d87e4a5057dd6cbafdeafde8"
bot_token = "8168457236:AAG6kvmN0CVnMINIEG7plGqBgGZ_hTnFjUI"

# ✅ قائمة المستخدمين المصرح لهم باستخدام البوت
AUTHORIZED_USERS = [7255189049, 1726923679]

# ✅ تعيين الجلسة مسبقًا
session_string = "BAGpHS0Af2Qwt4J67D0QtT-XWWn3A-ILaqJPLrytuftI8CsRrZoN5BRdrfOkk1gON6T-xqLMuc90pXB3VRvu2K1lDya55hnByNW66gJiAO0cToWPLDi_UjN8SFmzSkoQDm5ze9ggrH50iZJb5m9MDTbe9hToWL-up1Oh2n8u9hHVWx3ygS6P_WFjdPQVseb-eMMVu_6pqBLNeJLyHzR9YmnN_UzvPnVin3hngpYvG0AKlrhMph8uYlo2GaUWnLrN6TykJeiXZnA08MTarB3LgRIRGLs4ddyJrHdylQ1E56EC6p3iimT1k4vPs_G4U9R9CRdUSmivY6xYmNahA9mQTuXHlTT_gQAAAAHm4MQUAQ"

# ✅ تشغيل الحساب باستخدام الجلسة المعينة مسبقًا
acc = Client("user_session", api_id=api_id, api_hash=api_hash, session_string=session_string)
acc.start()

# ✅ تشغيل بوت التليغرام
bot = Client("bot_session", api_id=api_id, api_hash=api_hash, bot_token=bot_token)

# 🔹 دالة التحقق من صلاحية المستخدم
def is_authorized(user_id):
    return user_id in AUTHORIZED_USERS

# 🔹 أمر /start لعرض الأزرار
@bot.on_message(filters.command("start"))
def start(client, message):
    if not is_authorized(message.from_user.id):
        client.send_message(message.chat.id, "🚫 ليس لديك صلاحية لاستخدام هذا البوت.")
        return

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔐 تشفير ملفات بايثون", callback_data="encrypt")],
        [InlineKeyboardButton("📥 تحميل ملفات مقيدة", callback_data="download")]
    ])

    client.send_message(
        message.chat.id,
        f"👋 مرحبًا **{message.from_user.mention}**!\n"
        "اختر إحدى الميزات المتاحة:",
        reply_markup=keyboard
    )

# 🔹 التعامل مع الأزرار
@bot.on_callback_query()
def callback_handler(client, callback_query):
    user_id = callback_query.from_user.id

    if not is_authorized(user_id):
        callback_query.answer("🚫 ليس لديك صلاحية لاستخدام هذا البوت.", show_alert=True)
        return

    if callback_query.data == "encrypt":
        bot.send_message(callback_query.message.chat.id, "🔐 أرسل ملف Python (.py) لتشفيره.")
    elif callback_query.data == "download":
        bot.send_message(callback_query.message.chat.id, "📥 أرسل رابط منشور مقيد لاستخراجه.")

# 🔹 معالجة تشفير الملفات
@bot.on_message(filters.document)
def encrypt_file(client, message: Message):
    if not is_authorized(message.from_user.id):
        client.send_message(message.chat.id, "🚫 ليس لديك صلاحية لاستخدام هذا البوت.")
        return

    file_id = message.document.file_id
    file_name = message.document.file_name
    file_path = f"./{file_name}"

    client.download_media(file_id, file_path)

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source_code = f.read()

        compiled_code = compile(source_code, "<string>", "exec")
        encrypted_code = marshal.dumps(compiled_code)

        final_code = f"""
import sys
import marshal
if sys.version_info >= (3, 9):
    exec(marshal.loads({repr(encrypted_code)}))
else:
    print(f'# لا يوجد دعم لإصدار Python {sys.version_info[0]}.{sys.version_info[1]}')
"""

        encoded_file_path = f"encoded_{message.from_user.id}.py"
        with open(encoded_file_path, "w", encoding="utf-8") as f:
            f.write(final_code)

        client.send_document(
            message.chat.id,
            encoded_file_path,
            caption="✅ تم تشفير الملف بنجاح!"
        )

        os.remove(file_path)
        os.remove(encoded_file_path)

    except Exception as e:
        client.send_message(message.chat.id, f"❌ حدث خطأ: {e}")

# 🔹 معالجة تحميل الملفات المقيدة
@bot.on_message(filters.text)
def process_message(client, message):
    if not is_authorized(message.from_user.id):
        client.send_message(message.chat.id, "🚫 ليس لديك صلاحية لاستخدام هذا البوت.")
        return

    if "https://t.me/+" in message.text or "https://t.me/joinchat/" in message.text:
        if acc is None:
            bot.send_message(message.chat.id, "❌ **لم يتم تعيين الجلسة!**")
            return
        try:
            acc.join_chat(message.text)
            bot.send_message(message.chat.id, "✅ **تم الانضمام إلى المجموعة!**")
        except UserAlreadyParticipant:
            bot.send_message(message.chat.id, "✅ **تم الانضمام مسبقًا!**")
        except InviteHashExpired:
            bot.send_message(message.chat.id, "❌ **الرابط غير صالح!**")
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ **خطأ:** {e}")

    elif "https://t.me/" in message.text:
        datas = message.text.split("/")
        try:
            msg_id = int(datas[-1].split("?")[0])
            chat_id = int("-100" + datas[-2]) if "https://t.me/c/" in message.text else datas[-2]

            if acc is None:
                bot.send_message(message.chat.id, "❌ **لم يتم تعيين الجلسة!**")
                return

            msg = acc.get_messages(chat_id, msg_id)
            copy_or_download(message, msg)

        except Exception as e:
            bot.send_message(message.chat.id, f"❌ **خطأ:** {e}")

# 🔹 وظائف تحميل ورفع الملفات
def downstatus(statusfile, message):
    while not os.path.exists(statusfile):
        time.sleep(1)
    while os.path.exists(statusfile):
        with open(statusfile, "r") as downread:
            txt = downread.read()
        try:
            bot.edit_message_text(message.chat.id, message.id, f"📥 تحميل: **{txt}**")
            time.sleep(5)
        except:
            time.sleep(3)

def progress(current, total, message, type):
    with open(f"{message.id}{type}status.txt", "w") as fileup:
        fileup.write(f"{current * 100 / total:.1f}%")

def copy_or_download(message, msg):
    if msg.text:
        bot.send_message(message.chat.id, msg.text, entities=msg.entities)
        return

    smsg = bot.send_message(message.chat.id, "📥 جارِ التحميل...")
    dosta = threading.Thread(target=lambda: downstatus(f"{message.id}downstatus.txt", smsg), daemon=True)
    dosta.start()

    file = acc.download_media(msg, progress=progress, progress_args=[message, "down"])
    os.remove(f"{message.id}downstatus.txt")

    bot.send_document(message.chat.id, file)
    os.remove(file)
    bot.delete_messages(message.chat.id, [smsg.id])

# 🔹 تشغيل البوت
bot.run()