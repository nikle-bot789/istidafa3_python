import socket
import ipaddress
import time
from concurrent.futures import ThreadPoolExecutor
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackContext, ConversationHandler, MessageHandler, filters
from colorama import Fore, init
import os
from datetime import datetime

# تهيئة Colorama
init(autoreset=True)

# قائمة معرفات المستخدمين المسموح لهم باستخدام البوت
ALLOWED_USERS = [1726923679, 7255189049]  # استبدل هذه بـ ID المستخدمين المسموح لهم

# تعريف الحالات
START_IP, END_IP, PORT = range(3)

def generer_plage_ip(start_ip, end_ip):
    start = int(ipaddress.IPv4Address(start_ip))
    end = int(ipaddress.IPv4Address(end_ip))
    return [str(ipaddress.IPv4Address(ip)) for ip in range(start, end + 1)]

def tester_adresse_ip(adresse_ip, port, open_ips):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.1)
    try:
        result = sock.connect_ex((adresse_ip, port))
        if result == 0:
            open_ips.append(adresse_ip)
    finally:
        sock.close()

async def tester_adresses_ip(update: Update, context: CallbackContext, adresses_ip, port):
    open_ips = []
    total_ips = len(adresses_ip)  # حساب عدد الأيبيات المفحوصة
    
    with ThreadPoolExecutor(max_workers=1000) as executor:
        futures = [executor.submit(tester_adresse_ip, ip, port, open_ips) for ip in adresses_ip]
        for future in futures:
            future.result()
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"open_ips_{timestamp}.txt"
    
    if open_ips:
        with open(file_name, 'w') as file:
            file.write("\n".join(open_ips))
        
        await update.message.reply_text(
            f"*✅ تم العثور على عناوين IP مفتوحة على المنفذ {port}.*\n"
            f"📊 *عدد الأيبيات المفحوصة:* `{total_ips}`\n"
            f"📜 *عدد الأيبيات المفتوحة:* `{len(open_ips)}`", 
            parse_mode='Markdown'
        )
        
        await context.bot.send_document(chat_id=update.effective_chat.id, document=open(file_name, 'rb'))
        os.remove(file_name)
    else:
        await update.message.reply_text(
            f"❌ لم يتم العثور على أي عنوان IP مفتوح على المنفذ {port}.\n"
            f"📊 *عدد الأيبيات المفحوصة:* `{total_ips}`", 
            parse_mode='Markdown'
        )

async def start(update: Update, context: CallbackContext):
    user_id = update.message.from_user.id
    if user_id not in ALLOWED_USERS:
        await update.message.reply_text("🚫 ليس لديك إذن لاستخدام هذا البوت.")
        return ConversationHandler.END

    await update.message.reply_text("📌 أدخل رقم البورت الذي تريد فحصه:")
    return PORT

async def handle_port(update: Update, context: CallbackContext):
    try:
        port = int(update.message.text)
        if 1 <= port <= 65535:
            context.user_data['port'] = port
            await update.message.reply_text("✍️ أدخل عنوان الـ IP البداية للفحص.")
            return START_IP
        else:
            await update.message.reply_text("⚠️ الرجاء إدخال رقم بورت صحيح بين 1 و 65535.")
            return PORT
    except ValueError:
        await update.message.reply_text("⚠️ الرجاء إدخال رقم بورت صحيح.")
        return PORT

async def handle_start_ip(update: Update, context: CallbackContext):
    start_ip = update.message.text
    try:
        ipaddress.IPv4Address(start_ip)
        context.user_data['start_ip'] = start_ip
        await update.message.reply_text("✍️ أدخل عنوان الـ IP النهاية للفحص.")
        return END_IP
    except ipaddress.AddressValueError:
        await update.message.reply_text("⚠️ الرجاء إدخال عنوان IP بداية صحيح.")
        return START_IP

async def handle_end_ip(update: Update, context: CallbackContext):
    end_ip = update.message.text
    start_ip = context.user_data.get('start_ip')
    port = context.user_data.get('port')
    
    try:
        ipaddress.IPv4Address(end_ip)
        context.user_data['end_ip'] = end_ip

        adresses = generer_plage_ip(start_ip, end_ip)
        
        await update.message.reply_text("⏳ بدء فحص الأيبيات... قد يستغرق هذا بعض الوقت.")
        await tester_adresses_ip(update, context, adresses, port)
        
        return ConversationHandler.END
    except ipaddress.AddressValueError:
        await update.message.reply_text("⚠️ الرجاء إدخال عنوان IP نهاية صحيح.")
        return END_IP

async def cancel(update: Update, context: CallbackContext):
    await update.message.reply_text("🚫 تم إلغاء العملية.")
    return ConversationHandler.END

def main():
    application = Application.builder().token("7966718203:AAHYPm_JgAhdx2NoeZ_ILTQoMi15tnsBfu8").build()
    
    conversation_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            PORT: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_port)],
            START_IP: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_start_ip)],
            END_IP: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_end_ip)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )
    
    application.add_handler(conversation_handler)
    application.run_polling()

if __name__ == '__main__':
    while True:
        try:
            print("🚀 يتم تشغيل البوت...")
            main()
        except Exception as e:
            print(f"⚠️ حدث خطأ: {e}. إعادة تشغيل البوت بعد 5 ثوانٍ.")
            time.sleep(5)