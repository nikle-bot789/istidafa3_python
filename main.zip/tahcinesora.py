import logging
import io
from PIL import Image, ImageEnhance
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext

# إعداد السجلات
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# دالة تحسين جودة الصورة
def enhance_image(image: Image.Image) -> Image.Image:
    enhancer = ImageEnhance.Sharpness(image)
    enhanced_image = enhancer.enhance(2.0)  # تحسين الحدة
    enhancer = ImageEnhance.Contrast(enhanced_image)
    enhanced_image = enhancer.enhance(1.5)  # تحسين التباين
    return enhanced_image

# دالة لاستقبال ومعالجة الصور
async def handle_photo(update: Update, context: CallbackContext) -> None:
    photo_file = await update.message.photo[-1].get_file()
    photo = await photo_file.download_as_bytearray()

    image = Image.open(io.BytesIO(photo))
    enhanced_image = enhance_image(image)

    enhanced_image_io = io.BytesIO()
    enhanced_image.save(enhanced_image_io, format='PNG')
    enhanced_image_io.seek(0)

    await update.message.reply_photo(photo=enhanced_image_io)

    enhanced_image_io.close()
    image.close()

# دالة بدء البوت
async def start(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text('مرحبًا! أرسل لي صورة لتحسين جودتها.')

# إعداد البوت وتشغيله
def main():
    BOT_TOKEN = "7781874465:AAHw6d25CkHne5Bq_xH8uwsVJ8qO2VSn4WM"

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))

    app.run_polling()

if name == '__main__':
    main()