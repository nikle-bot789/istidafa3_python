import telebot
from telebot import types
import requests
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

token = "7781874465:AAHw6d25CkHne5Bq_xH8uwsVJ8qO2VSn4WM"
bot = telebot.TeleBot(token)

usrpg = {}

dat = {}

def getp(city):
    
    url = f"https://api.aladhan.com/v1/timingsByCity?city={city}&country=IQ&method=5"  
    r = requests.get(url).json()
    
    t = r["data"]["timings"]  

    def fix_time(time_str):  
        h, m = map(int, time_str.split(":"))  
        period = "ص" if h < 12 else "م"  
        h = h % 12 or 12  
        return f"{h}:{m} {period}"  

    return (f"**مواقيت الصلاة لـ {city}**:\n"  
            f"الفجر: {fix_time(t['Fajr'])}\n"  
            f"الشروق: {fix_time(t['Sunrise'])}\n"  
            f"الظهر: {fix_time(t['Dhuhr'])}\n"  
            f"العصر: {fix_time(t['Asr'])}\n"  
            f"المغرب: {fix_time(t['Maghrib'])}\n"  
            f"العشاء: {fix_time(t['Isha'])}")

def main(chatid, msgid=None):
    
    
    key = InlineKeyboardMarkup(row_width=2)
    key.add(InlineKeyboardButton("مواقيت الصلاة", callback_data="pray"))
    
    key.add(InlineKeyboardButton("تسبيح", callback_data="sbh"))
    key.add(InlineKeyboardButton("القرآن الكريم", callback_data="mt"))
    
    key.add(InlineKeyboardButton("بحث عن سورة", callback_data="search"))

    if msgid:  
        bot.edit_message_text("اهلا بك مره اخرى", chatid, msgid, reply_markup=key)
        
    else:
        
        bot.send_message(chatid, "اهلا بك في بوت القرأن الكريم", reply_markup=key)

@bot.message_handler(commands=["start"])
def start(msg):
    dat[msg.chat.id] = 0
    main(msg.chat.id)

@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    
    cid = call.message.chat.id
    
    if call.data == "sbh":
        sbh(call)
        
    elif call.data == "mt":
        usrpg[cid] = 1
        
        see(call.message, 1)
    elif call.data == "search":
        bot.send_message(cid, "ارسل رقم الصفحه الان.")
        bot.register_next_step_handler_by_chat_id(cid, ser)
    elif call.data == "inc":
        if dat[cid] < 34:
            dat[cid] += 1
        sbh(call)
    elif call.data == "rst":
        dat[cid] = 0
        sbh(call)
    elif call.data == "bck":
        main(cid, call.message.id)
    elif call.data == "pray":
        pryl(call)
    elif call.data in iraq:
        bot.edit_message_text(getp(call.data), cid, call.message.id, parse_mode="Markdown", reply_markup=bck())
    elif call.data == "next":
        change_page(call, 1)
    elif call.data == "prev":
        change_page(call, -1)

def see(message, page=1):

    uid = message.chat.id
    usrpg[uid] = page
    
    imgurl = f"https://quran.ksu.edu.sa/png_big/{page}.png"
    
    markup = InlineKeyboardMarkup(row_width=2)
    nextbtn = InlineKeyboardButton("التالي", callback_data="next")
    prevbtn = InlineKeyboardButton("السابق", callback_data="prev")
    markup.add(prevbtn,nextbtn)

    bot.send_photo(uid, imgurl, caption=f"📖 رقم الصفحة: {page}", reply_markup=markup)

def ser(message):

    try:
        pagenum = int(message.text)
        if pagenum < 1 or pagenum > 604:
            bot.send_message(message.chat.id, "⚠️ رقم الصفحة غير صحيح! يجب أن يكون بين 1 و 604.")
        else:
            imgurl = f"https://quran.ksu.edu.sa/png_big/{pagenum}.png"
            bot.send_photo(message.chat.id, imgurl, caption=f"📖 رقم الصفحة  {pagenum}")
    except ValueError:
        bot.send_message(message.chat.id, "⚠️ أدخل رقم صفحة صحيح!")

def change_page(call, direction):

    uid = call.message.chat.id
    pgnum = usrpg.get(uid, 1) + direction

    if 1 <= pgnum <= 604:
        usrpg[uid] = pgnum
        imgurl = f"https://quran.ksu.edu.sa/png_big/{pgnum}.png"
        bot.edit_message_media(media=types.InputMediaPhoto(imgurl, caption=f"📖 رقم الصفحة: {pgnum}"),
                               chat_id=uid, message_id=call.message.message_id, reply_markup=call.message.reply_markup)
    else:
        bot.answer_callback_query(call.id, "📖 لا يوجد صفحات أخرى!")

def sbh(call):

    cid = call.message.chat.id
    num = dat.get(cid, 0)
    txt = "💠" if num == 0 else "🟢"
    key = InlineKeyboardMarkup()
    key.add(InlineKeyboardButton(f"{txt} {num}", callback_data="inc"))
    key.add(InlineKeyboardButton("🔄 تصفير", callback_data="rst"))
    key.add(InlineKeyboardButton("🔙 رجوع", callback_data="bck"))
    bot.edit_message_text("اضغط للتسبيح:", cid, call.message.id, reply_markup=key)

def pryl(call):

    key = InlineKeyboardMarkup(row_width=3)
    btns = [InlineKeyboardButton(c, callback_data=c) for c in iraq]
    
    key.add(*btns)
    key.add(InlineKeyboardButton("🔙 رجوع", callback_data="bck"))
    bot.edit_message_text("انقر عل محافضتك الان!!", call.message.chat.id, call.message.id, reply_markup=key)

def bck():
    
    key = InlineKeyboardMarkup(row_width=2)
    key.add(InlineKeyboardButton("🕌 مواقيت الصلاة", callback_data="pray"),
            InlineKeyboardButton("👐 تسبيح", callback_data="sbh"))
    return key

iraq = ["بغداد", "البصرة", "نينوى", "كربلاء", "النجف", "واسط", "السليمانية", "دهوك",
        "المثنى", "بابل", "ديالى", "ذي قار", "الأنبار", "كركوك", "صلاح الدين", "ميسان", "القادسية"]

bot.polling()