import subprocess
import os
import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.filters import Command
import importlib
import sys

# 🔑 Configuration du bot
TOKEN = "8138617568:AAFAxy92BE3LQJdK1oUKmzLgaonUJVTALlg"  # Remplace par ton token
AUTHORIZED_ID = 1726923679  # Remplace par ton ID Telegram
BASE_DIR = "scripts"
processes = {}
user_states = {}  # Dictionnaire pour suivre l'état de l'utilisateur (exécution/suppression/ajout)

# 📂 Création du dossier des scripts si non existant
os.makedirs(BASE_DIR, exist_ok=True)

bot = Bot(token=TOKEN)
dp = Dispatcher()

# 🎛️ Clavier principal
main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="➕ Ajouter un script")],
        [KeyboardButton(text="▶️ Exécuter un script")],
        [KeyboardButton(text="🔄 Redémarrer tous")],
        [KeyboardButton(text="📜 Liste des scripts")],
        [KeyboardButton(text="❌ Arrêter et Supprimer un script")],
    ],
    resize_keyboard=True
)

# 📦 Fonction pour vérifier et installer les bibliothèques manquantes
def install_missing_libraries():
    try:
        # Vérification des bibliothèques installées
        with open('scripts/requirements.txt', 'r') as f:
            for line in f:
                package = line.strip()
                try:
                    importlib.import_module(package)
                except ImportError:
                    print(f"📦 La bibliothèque {package} est manquante. Installation...")
                    subprocess.check_call([sys.executable, "-m", "pip", "install", package])
                    print(f"✅ La bibliothèque {package} a été installée.")
    except FileNotFoundError:
        print("⚠️ Aucun fichier requirements.txt trouvé. Vérifiez vos bibliothèques.")

# 📂 Commande /start
@dp.message(Command("start"))
async def start(message: types.Message):
    if message.from_user.id != AUTHORIZED_ID:
        await message.reply("❌ Accès refusé !")
        return
    await message.reply("👋 Bienvenue ! Choisissez une action :", reply_markup=main_keyboard)

# ➕ Ajouter un script
@dp.message(lambda message: message.text == "➕ Ajouter un script")
async def prompt_add_script(message: types.Message):
    user_states[message.from_user.id] = "ajout_script"
    await message.reply("📤 Envoie-moi un fichier **.py** pour l'ajouter au système.")

@dp.message(lambda message: message.document and user_states.get(message.from_user.id) == "ajout_script")
async def handle_script_upload(message: types.Message):
    document = message.document

    if not document.file_name.endswith(".py"):
        await message.reply("⚠️ Seuls les fichiers `.py` sont acceptés.")
        return

    file_path = os.path.join(BASE_DIR, document.file_name)
    file = await bot.get_file(document.file_id)
    await bot.download_file(file.file_path, file_path)

    # Vérifier et installer les dépendances du script s'il en a
    install_missing_libraries()  # Installer les bibliothèques manquantes

    await message.reply(f"✅ Script **{document.file_name}** ajouté avec succès !")
    user_states.pop(message.from_user.id, None)  # Réinitialiser l'état de l'utilisateur

# ▶️ Exécuter un script
@dp.message(lambda message: message.text == "▶️ Exécuter un script")
async def list_files_for_running(message: types.Message):
    user_states[message.from_user.id] = "execution"
    files = os.listdir(BASE_DIR)
    if not files:
        await message.reply("🚫 Aucun script trouvé.")
        return

    # Organiser les boutons en colonnes (4 par ligne)
    buttons = [KeyboardButton(text=file) for file in files]
    keyboard_layout = [buttons[i:i+4] for i in range(0, len(buttons), 4)]
    keyboard_layout.append([KeyboardButton(text="⬅️ Retour au menu")])

    keyboard = ReplyKeyboardMarkup(keyboard=keyboard_layout, resize_keyboard=True)
    await message.reply("🔍 Sélectionne un script à exécuter :", reply_markup=keyboard)

@dp.message(lambda message: message.text in os.listdir(BASE_DIR))
async def handle_script_selection(message: types.Message):
    user_id = message.from_user.id
    filename = message.text
    file_path = os.path.join(BASE_DIR, filename)

    if user_states.get(user_id) == "execution":
        await message.reply(f"🚀 Exécution du script {filename}...")

        # Vérifier et installer les dépendances avant d'exécuter
        install_missing_libraries()  # Installer les bibliothèques nécessaires

        process = await asyncio.create_subprocess_exec(
            'python', file_path, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        processes[filename] = process

        stdout, stderr = await process.communicate()

        if stdout:
            await message.reply(f"📤 **Sortie :**\n```\n{stdout.decode()}\n```", parse_mode="Markdown")
        if stderr:
            await message.reply(f"⚠️ **Erreurs :**\n```\n{stderr.decode()}\n```", parse_mode="Markdown")

        user_states.pop(user_id, None)  # Réinitialiser l'état de l'utilisateur

# ❌ Arrêter et supprimer un script
@dp.message(lambda message: message.text == "❌ Arrêter et Supprimer un script")
async def stop_and_delete_script(message: types.Message):
    user_states[message.from_user.id] = "suppression"
    files = os.listdir(BASE_DIR)
    if not files:
        await message.reply("🚫 Aucun script trouvé à supprimer.")
        return

    buttons = [KeyboardButton(text=file) for file in files]
    keyboard_layout = [buttons[i:i+4] for i in range(0, len(buttons), 4)]
    keyboard_layout.append([KeyboardButton(text="⬅️ Retour au menu")])

    keyboard = ReplyKeyboardMarkup(keyboard=keyboard_layout, resize_keyboard=True)
    await message.reply("🔍 Sélectionne un script à arrêter et supprimer :", reply_markup=keyboard)

# 🔄 Redémarrer tous les scripts
@dp.message(lambda message: message.text == "🔄 Redémarrer tous")
async def restart_all_codes(message: types.Message):
    for filename in list(processes.keys()):
        process = processes[filename]
        if process.returncode is None:
            process.terminate()
            try:
                await process.wait(timeout=5)
            except asyncio.TimeoutError:
                process.kill()
        del processes[filename]

    # Redémarrer tous les scripts
    for filename in os.listdir(BASE_DIR):
        file_path = os.path.join(BASE_DIR, filename)
        process = await asyncio.create_subprocess_exec(
            'python', file_path, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        processes[filename] = process

    await message.reply("♻️ Tous les scripts ont été redémarrés.")

# 📜 Liste des scripts avec statut
@dp.message(lambda message: message.text == "📜 Liste des scripts")
async def list_codes(message: types.Message):
    files = os.listdir(BASE_DIR)
    if not files:
        await message.reply("🚫 Aucun script trouvé.")
        return

    status = {file: "🟢 Actif" if file in processes and processes[file].returncode is None else "🔴 Arrêté" for file in files}
    response = "\n".join([f"{file}: {state}" for file, state in status.items()])
    await message.reply(f"📂 Scripts disponibles :\n{response}")

# Bouton de retour au menu principal
@dp.message(lambda message: message.text == "⬅️ Retour au menu")
async def return_to_main_menu(message: types.Message):
    user_states.pop(message.from_user.id, None)  # Réinitialiser l'état de l'utilisateur
    await message.reply("🏠 Retour au menu principal.", reply_markup=main_keyboard)

# 🚀 Lancement du bot
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
