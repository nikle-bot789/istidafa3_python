try:
    import telebot
    import os
    import zipfile
    from PIL import Image
    from io import BytesIO
except ImportError:
    os.system('pip install PyTelegramBotAPI')
    os.system('pip install pillow')

Token = '8138617568:AAGB--tS2mCzxqh0FV43EDoxqSeQHCzNWzY'  # استبدل هذا بالتوكن الخاص بك
bot = telebot.TeleBot(Token)
F = 'files'
if not os.path.exists(F):
    os.makedirs(F)

imgs = []
files = []

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.send_message(message.chat.id, 'اهلا بك عزيزي في بوت ضغط الملفات والصور لملف zip')

@bot.message_handler(content_types=['photo'])
def handle_photo(m):
    fi = bot.get_file(m.photo[-1].file_id)
    df = bot.download_file(fi.file_path)

    img = Image.open(BytesIO(df))
    ip = os.path.join(F, f"{m.photo[-1].file_id}.jpg")
    img.save(ip)
    imgs.append(ip)

    bot.reply_to(m, f"تم استلام {len(imgs)} صورة!")

@bot.message_handler(content_types=['document'])
def handle_document(m):
    fi = bot.get_file(m.document.file_id)
    df = bot.download_file(fi.file_path)

    doc_path = os.path.join(F, m.document.file_name)
    
    with open(doc_path, 'wb') as doc_file:
        doc_file.write(df)
    
    files.append(doc_path)
    
    bot.reply_to(m, f"تم استلام الملف: {m.document.file_name}")

def compress_files(output_zip, files_list):
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for file in files_list:
            zf.write(file, os.path.basename(file))

@bot.message_handler(func=lambda m: m.text and m.text.lower() == "ضغط")
def compress_and_send(m):
    all_files = imgs + files
    if len(all_files) == 0:
        bot.reply_to(m, "لم يتم استلام أي ملفات أو صور!")
        return

    zip_filename = "compressed_files.zip"
    compress_files(zip_filename, all_files)

    with open(zip_filename, 'rb') as f:
        bot.send_document(m.chat.id, f)

    for i in imgs:
        os.remove(i)
    for f in files:
        os.remove(f)
    
    imgs.clear()
    files.clear()
    
    os.remove(zip_filename)
    bot.reply_to(m, "تم ضغط الملفات وإرسال الملف!")

print('تم تشغيل البوت')
bot.polling()