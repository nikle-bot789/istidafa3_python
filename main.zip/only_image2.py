import subprocess
import sys

# Fonction pour installer une bibliothèque si elle n'est pas installée
def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Liste des bibliothèques nécessaires
required_packages = [
    "python-telegram-bot",
    "pillow",
]

# Installation automatique des bibliothèques manquantes
for package in required_packages:
    try:
        __import__(package.replace("-", "_"))
    except ImportError:
        print(f"Installation de {package}...")
        install(package)

# Importations après installation
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from PIL import Image
import os

# Dossier temporaire pour stocker les fichiers
TEMP_DIR = "temp_files"
if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR)

# Compteur global pour suivre l'ordre des fichiers
file_counter = 0

# Commande /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("Convertir les images en PDF", callback_data='convert_image')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "Bienvenue ! Envoyez-moi vos fichiers PDF ou images. Ensuite, utilisez le bouton pour convertir.",
        reply_markup=reply_markup
    )

# Gérer les fichiers PDF et images
async def handle_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    global file_counter
    document = update.message.document
    if document.mime_type.startswith("image/"):
        # Télécharger et enregistrer l'image avec un compteur pour garantir l'ordre
        file_id = document.file_id
        file_path = os.path.join(TEMP_DIR, f"{file_counter}_{file_id}.jpg")
        file = await context.bot.get_file(file_id)
        await file.download_to_drive(file_path)
        file_counter += 1
        await update.message.reply_text("Image reçue et prête pour la conversion.")
    else:
        await update.message.reply_text("Veuillez envoyer uniquement des images.")

# Gérer les photos envoyées comme image
async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    global file_counter
    photo = update.message.photo[-1]  # Prendre la meilleure résolution de l'image
    file_id = photo.file_id
    file_path = os.path.join(TEMP_DIR, f"{file_counter}_{file_id}.jpg")
    file = await context.bot.get_file(file_id)
    await file.download_to_drive(file_path)
    file_counter += 1
    await update.message.reply_text("Photo reçue et prête pour la conversion.")

# Convertir les images en PDF
async def convert_images_to_pdf(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    # Trier les fichiers par ordre de réception
    image_files = sorted(
        [os.path.join(TEMP_DIR, f) for f in os.listdir(TEMP_DIR) if f.endswith((".jpg", ".jpeg", ".png"))],
        key=lambda x: int(os.path.basename(x).split("_")[0])
    )
    if not image_files:
        await query.edit_message_text(text="Aucune image trouvée pour la conversion.")
        return

    # Créer un PDF contenant toutes les images
    output_path = os.path.join(TEMP_DIR, "images_to_pdf.pdf")
    pdf_images = []
    for image_file in image_files:
        image = Image.open(image_file)
        pdf_images.append(image.convert("RGB"))

    pdf_images[0].save(output_path, save_all=True, append_images=pdf_images[1:])
    for image in pdf_images:
        image.close()

    with open(output_path, 'rb') as f:
        await query.message.reply_document(f, filename="Images_Converties.pdf", caption="Voici votre fichier PDF.")

    # Nettoyer les fichiers temporaires
    for image_file in image_files:
        os.remove(image_file)
    os.remove(output_path)

# Fonction principale
def main():
    TOKEN = "6718527609:AAFDmEsbBRz0vdkVuybpuSFx4gdrLyyTOQ0"  # Remplacez par votre token
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.Document.IMAGE, handle_file))
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))  # Nouveau gestionnaire pour les photos
    application.add_handler(CallbackQueryHandler(convert_images_to_pdf, pattern="convert_image"))

    # Lancer le bot
    try:
        asyncio.get_event_loop().run_until_complete(application.run_polling())
    except RuntimeError as e:
        if "This event loop is already running" in str(e):
            print("Boucle d'événements déjà active. Exécution adaptée pour Pydroid3.")
            application.run_polling()
        else:
            raise

    # Nettoyer les fichiers temporaires à la fin
    clean_temp_dir()

# Nettoyage des fichiers temporaires
def clean_temp_dir():
    if os.path.exists(TEMP_DIR):
        for file in os.listdir(TEMP_DIR):
            os.remove(os.path.join(TEMP_DIR, file))
        os.rmdir(TEMP_DIR)

if __name__ == "__main__":
    main()