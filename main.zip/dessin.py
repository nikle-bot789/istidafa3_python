import time
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from PIL import Image, ImageDraw, ImageFont
import io

# Fonction pour créer une image avec du texte bleu
def create_image_with_text(text: str) -> io.BytesIO:
    # Créer une image blanche
    img = Image.new('RGB', (800, 200), color='white')
    d = ImageDraw.Draw(img)

    # Utiliser une police de texte (vous pouvez remplacer le chemin si nécessaire)
    font = ImageFont.load_default()

    # Couleur bleue pour le texte
    text_color = (0, 0, 255)

    # Positionner le texte sur l'image
    d.text((10, 60), text, font=font, fill=text_color)

    # Sauvegarder l'image dans un objet BytesIO pour l'envoyer comme fichier
    image_bytes = io.BytesIO()
    img.save(image_bytes, format='PNG')
    image_bytes.seek(0)  # Revenir au début du fichier

    return image_bytes

# Fonction pour envoyer l'image avec un effet de tapement humain
async def type_like_human(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = "Voici un texte écrit comme un humain. 🤖"
    delay = 0.3  # Délai entre chaque caractère

    # Créer l'image et l'envoyer au fur et à mesure du tapement
    for i in range(1, len(text) + 1):
        current_text = text[:i]
        
        # Créer une image avec le texte actuel
        image_bytes = create_image_with_text(current_text)

        # Envoyer l'image
        await update.message.reply_photo(photo=image_bytes)

        # Attendre avant d'envoyer le prochain morceau
        time.sleep(delay)

# Fonction principale qui démarre le bot
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Bienvenue dans le bot ! Tapez /type pour voir l'effet de l'écriture.")

def main() -> None:
    # Remplacez 'YOUR_TOKEN' par votre token d'API Telegram
    application = Application.builder().token("8138617568:AAGB--tS2mCzxqh0FV43EDoxqSeQHCzNWzY").build()

    # Commande '/start' pour démarrer le bot
    application.add_handler(CommandHandler("start", start))

    # Commande '/type' pour lancer l'effet de tapement
    application.add_handler(CommandHandler("type", type_like_human))

    # Lancer le bot
    application.run_polling()

if __name__ == '__main__':
    main()