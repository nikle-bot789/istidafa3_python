import telebot
from telebot import types
#امسح فقط كلمه توكن الي داخل علامه الاقتباس وخلي توكن بوتك وشغل لملف وروح لبوتك تحكم هناك
token = "7781874465:AAHw6d25CkHne5Bq_xH8uwsVJ8qO2VSn4WM"
ttxxxn = telebot.TeleBot(token)
d = {}

def hso(c, u):
    if c not in d:
        d[c] = ""
    if u.data == "=":
        try:
            d[c] = str(eval(d[c]))
        except:
            d[c] = "خطأ"
    elif u.data == "C":
        d[c] = "0"
    else:
        if d[c] == "0":
            d[c] = u.data
        else:
            d[c] += u.data
    k = gu()
    ttxxxn.edit_message_text(chat_id=u.message.chat.id, message_id=u.message.message_id, text=d[c], reply_markup=k)

def gu():
    k = types.InlineKeyboardMarkup()
    b1 = [types.InlineKeyboardButton(str(i), callback_data=str(i)) for i in range(1, 4)]
    b2 = [types.InlineKeyboardButton(str(i), callback_data=str(i)) for i in range(4, 7)]
    b3 = [types.InlineKeyboardButton(str(i), callback_data=str(i)) for i in range(7, 10)]
    b4 = [types.InlineKeyboardButton("0", callback_data="0")]
    b5 = [types.InlineKeyboardButton("+", callback_data="+"),
          types.InlineKeyboardButton("-", callback_data="-"),
          types.InlineKeyboardButton("*", callback_data="*"),
          types.InlineKeyboardButton("/", callback_data="/")]
    b6 = [types.InlineKeyboardButton("=", callback_data="="), types.InlineKeyboardButton("C", callback_data="C")]
    k.row(*b1)
    k.row(*b2)
    k.row(*b3)
    k.row(*b4)
    k.row(*b5)
    k.row(*b6)
    my = types.InlineKeyboardButton(text='مبرمج البوت', url="https://t.me/ttxxxn")
    k.add(my)
    return k

@ttxxxn.message_handler(commands=["start"])
def start_message(m): 
    c = m.chat.id
    d[c] = ""
    k = gu()
    ttxxxn.send_message(c, "0", reply_markup=k)

@ttxxxn.callback_query_handler(func=lambda call: True)
def c_q(u):
    hso(u.message.chat.id, u)

ttxxxn.polling()