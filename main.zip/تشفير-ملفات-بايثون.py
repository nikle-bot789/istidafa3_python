import os
import subprocess
import sys

# قائمة المكتبات التي يحتاجها الكود
required_libraries = ["pyrogram"]

# دالة لتثبيت المكتبات
def install_libraries():
    for library in required_libraries:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", library])
        except subprocess.CalledProcessError:
            print(f"❌ فشل تثبيت المكتبة: {library}")

# تأكد من تثبيت المكتبات
install_libraries()

# الكود المتبقي كما هو
import json
import marshal
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

# 🔹 إعدادات API
api_id = 27860269
api_hash = "76df60f2d87e4a5057dd6cbafdeafde8"
bot_token = "8168457236:AAG6kvmN0CVnMINIEG7plGqBgGZ_hTnFjUI"

admin_id = 1726923679  # ضع هنا معرف الأدمن

# 🔹 ملف تخزين المستخدمين
USERS_FILE = "users.json"

# ✅ تحميل بيانات المستخدمين
def load_users():
    try:
        with open(USERS_FILE, "r") as f:
            data = json.load(f)
        if "approved_users" not in data:
            data["approved_users"] = []
        if "banned_users" not in data:
            data["banned_users"] = []
        return data
    except (json.JSONDecodeError, FileNotFoundError):
        default_data = {"approved_users": [], "banned_users": []}
        save_users(default_data)
        return default_data

# ✅ دالة حفظ المستخدمين
def save_users(data):
    with open(USERS_FILE, "w") as f:
        json.dump(data, f, indent=4)

# ✅ تحميل البيانات
users = load_users()

# ✅ تشغيل البوت
bot = Client("bot_session", api_id=api_id, api_hash=api_hash, bot_token=bot_token, workers=50)

# 🔹 أمر /id لإرسال الأيدي للمستخدم
@bot.on_message(filters.command("id"))
def send_id(client, message):
    user_id = message.from_user.id
    client.send_message(message.chat.id, f"🆔 **معرفك:** `{user_id}`")

# 🔹 أمر /start للتحقق من الموافقة على المستخدم
@bot.on_message(filters.command("start"))
def start(client, message):
    user_id = message.from_user.id
    username = message.from_user.first_name

    # ✅ إذا كان المستخدم محظورًا، لا يمكنه استخدام البوت
    if user_id in users["banned_users"]:
        client.send_message(user_id, "🚫 لقد تم حظرك من استخدام البوت.")
        return

    # ✅ إذا كان المستخدم غير موافق عليه، يتم إرسال طلب للأدمن
    if user_id not in users["approved_users"]:
        client.send_message(
            admin_id,
            f"🔔 طلب جديد من المستخدم:\n"
            f"👤 الاسم: {username}\n"
            f"🆔 المعرف: `{user_id}`\n\n"
            "❓ هل تريد قبول هذا المستخدم؟",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ قبول", callback_data=f"accept_{user_id}"),
                 InlineKeyboardButton("❌ رفض", callback_data=f"reject_{user_id}")]
            ])
        )
        #client.send_message(user_id, "⏳ تم إرسال طلبك إلى الأدمن، يرجى الانتظار للموافقة.")
        return

    # ✅ المستخدم مقبول - عرض رسالة الترحيب دائمًا عند الضغط على /start
    client.send_message(
        user_id,
        f"👋 مرحبًا {username}!\n"
        "أنا بوت لتشفير الملفات باستخدام Marshal.\n"
        "يرجى إرسال الملف الذي ترغب في تشفيره."
    )

# ✅ معالجة زر قبول أو رفض المستخدم
@bot.on_callback_query()
def handle_callback(client, callback_query):
    data = callback_query.data
    admin_user_id = callback_query.from_user.id

    if admin_user_id != admin_id:
        callback_query.answer("❌ ليس لديك صلاحية لتنفيذ هذا الإجراء.", show_alert=True)
        return

    if data.startswith("accept_"):
        user_id = int(data.split("_")[1])
        if user_id not in users["approved_users"]:
            users["approved_users"].append(user_id)
            save_users(users)
            client.send_message(user_id, "✅ تم قبولك في البوت! الرجاء الضغط على /start لبدء الاستخدام.")
            callback_query.answer("✅ تم قبول المستخدم.")
    elif data.startswith("reject_"):
        user_id = int(data.split("_")[1])
        users["banned_users"].append(user_id)
        save_users(users)
        client.send_message(user_id, "❌ تم رفض طلبك من قبل الأدمن.")
        callback_query.answer("❌ تم رفض المستخدم.")

# 🔹 معالجة إرسال الملفات (بدون تغيير)
@bot.on_message(filters.document)
def encrypt_file(client, message: Message):
    user_id = message.from_user.id  # الحصول على user_id لتمييز الملفات

    # ✅ التحقق مما إذا كان المستخدم مسموحًا له باستخدام البوت
    if user_id in users["banned_users"]:
        client.send_message(user_id, "🚫 لا يمكنك استخدام هذا البوت لأنك محظور.")
        return
    if user_id not in users["approved_users"]:
        client.send_message(user_id, "⏳ لم يتم قبولك بعد، يرجى الانتظار لموافقة الأدمن.")
        return

    file_id = message.document.file_id
    file_name = message.document.file_name
    file_path = f"./{file_name}"

    # تنزيل الملف المرسل
    client.download_media(file_id, file_path)

    # بدء عملية التشفير
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source_code = f.read()

        # 🔹 تشفير الملف باستخدام marshal
        compiled_code = compile(source_code, "<string>", "exec")
        encrypted_code = marshal.dumps(compiled_code)

        # 🔹 إنشاء كود نهائي يحتوي على exec
        final_code = f"""
import sys
import marshal

# التحقق من إصدار بايثون
if sys.version_info >= (3, 9):
    exec(marshal.loads({repr(encrypted_code)}))
else:
    print(f'# no support for Python version {sys.version_info[0]}.{sys.version_info[1]}')
"""

        # 🔹 تغيير اسم الملف ليشمل user_id لضمان التميز بين الملفات
        encoded_file_path = f"encodedfile_{user_id}.py"
        with open(encoded_file_path, "w", encoding="utf-8") as f:
            f.write(final_code)

        # 🔹 إرسال الملف المشفر
        client.send_document(
            message.chat.id,
            encoded_file_path,
            caption="✅ تم تشفير الملف بنجاح!"
        )

        # 🔹 حذف الملفات بعد إرسالها
        os.remove(file_path)
        os.remove(encoded_file_path)

    except Exception as e:
        client.send_message(message.chat.id, f"❌ حدث خطأ: {e}", reply_to_message_id=message.id)

# ✅ تشغيل البوت
bot.run()