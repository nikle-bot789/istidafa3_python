from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, CallbackQueryHandler, MessageHandler, filters, ContextTypes
import os

# Chemin pour stocker les fichiers (organisé par utilisateur)
FILE_STORAGE_PATH = "./uploaded_files"

# Fonction pour envoyer le menu principal avec les boutons
async def send_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("📂 Lister mes fichiers", callback_data="list_files")],
        [InlineKeyboardButton("📥 Récupérer un fichier", callback_data="get_file")],
        [InlineKeyboardButton("📤 Ajouter un fichier", callback_data="add_file")],
        [InlineKeyboardButton("🗑 Supprimer un fichier", callback_data="delete_file")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Bienvenue ! Que souhaitez-vous faire ?", reply_markup=reply_markup)

# Gestion des fichiers envoyés par l'utilisateur
async def handle_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    user_folder = os.path.join(FILE_STORAGE_PATH, str(user_id))

    if not os.path.exists(user_folder):
        os.makedirs(user_folder)

    document = update.message.document
    if document:
        file = await document.get_file()
        file_path = os.path.join(user_folder, document.file_name)
        await file.download_to_drive(file_path)
        await update.message.reply_text(f"Fichier enregistré : {document.file_name}")
    else:
        await update.message.reply_text("Aucun fichier trouvé.")

# Callback pour lister les fichiers
async def list_files(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    user_folder = os.path.join(FILE_STORAGE_PATH, str(user_id))

    if not os.path.exists(user_folder):
        await query.edit_message_text("Aucun fichier enregistré.")
        return

    files = os.listdir(user_folder)
    if files:
        await query.edit_message_text("Voici vos fichiers :\n" + "\n".join(files))
    else:
        await query.edit_message_text("Aucun fichier trouvé.")

# Callback pour récupérer un fichier
async def get_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    user_folder = os.path.join(FILE_STORAGE_PATH, str(user_id))

    files = os.listdir(user_folder)
    if not files:
        await query.edit_message_text("Aucun fichier disponible pour téléchargement.")
        return

    keyboard = [[InlineKeyboardButton(file, callback_data=f"download:{file}")] for file in files]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text("Choisissez un fichier à télécharger :", reply_markup=reply_markup)

# Callback pour télécharger un fichier spécifique
async def download_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    file_name = query.data.split("download:")[1]
    file_path = os.path.join(FILE_STORAGE_PATH, str(user_id), file_name)

    if os.path.exists(file_path):
        await query.message.reply_document(open(file_path, 'rb'))
    else:
        await query.edit_message_text("Fichier introuvable.")

# Callback pour ajouter un fichier
async def add_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    await query.edit_message_text("Envoyez simplement le fichier que vous souhaitez ajouter.")

# Callback pour supprimer un fichier
async def delete_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    user_folder = os.path.join(FILE_STORAGE_PATH, str(user_id))

    files = os.listdir(user_folder)
    if not files:
        await query.edit_message_text("Aucun fichier disponible à supprimer.")
        return

    keyboard = [[InlineKeyboardButton(f"Supprimer {file}", callback_data=f"delete:{file}")] for file in files]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text("Choisissez un fichier à supprimer :", reply_markup=reply_markup)

# Callback pour supprimer un fichier spécifique
async def delete_specific_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    file_name = query.data.split("delete:")[1]
    file_path = os.path.join(FILE_STORAGE_PATH, str(user_id), file_name)

    if os.path.exists(file_path):
        os.remove(file_path)
        await query.edit_message_text(f"Fichier {file_name} supprimé.")
    else:
        await query.edit_message_text("Fichier introuvable.")

def main():
    TOKEN = "7848279718:AAEXJ-ka1lutR4pQS5N8PRN5umcb6EdJCvA"  # Remplacez par votre token
    application = Application.builder().token(TOKEN).build()

    # Handlers
    application.add_handler(MessageHandler(filters.Document.ALL, handle_file))
    application.add_handler(MessageHandler(filters.COMMAND, send_menu))  # Utilisation de /start pour envoyer le menu
    application.add_handler(CallbackQueryHandler(list_files, pattern="^list_files$"))
    application.add_handler(CallbackQueryHandler(get_file, pattern="^get_file$"))
    application.add_handler(CallbackQueryHandler(add_file, pattern="^add_file$"))
    application.add_handler(CallbackQueryHandler(delete_file, pattern="^delete_file$"))
    application.add_handler(CallbackQueryHandler(download_file, pattern="^download:.*$"))
    application.add_handler(CallbackQueryHandler(delete_specific_file, pattern="^delete:.*$"))

    # Démarrer le bot
    application.run_polling()

if __name__ == "__main__":
    main()